package com.rahul.jms;

public class DataCheck {
int no=12;
String name="Rahul";
@Override
public String toString() {
	return "DataCheck [no=" + no + ", name=" + name + "]";
}
}
